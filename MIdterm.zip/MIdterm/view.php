<?php include 'db_connect.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>View Resumes</title>
    <link rel="stylesheet" href="view.css"> <!-- Optional if you want styling -->
</head>
<body>
<h2>Employee Resumes</h2>
<table border="1" cellpadding="10">
    <tr>
        <th>Name</th>
        <th>Department</th>
        <th>Filename</th>
        <th>Download</th>
        <th>Uploaded At</th>
    </tr>
    <div style="text-align: right; margin-bottom: 10px;">
    <a href="logout.php" style="padding: 8px 16px; background: #dc3545; color: #fff; text-decoration: none; border-radius: 5px;">Logout</a>
</div>
    <?php
    $result = $conn->query("SELECT * FROM resumes ORDER BY uploaded_at DESC");

    while ($row = $result->fetch_assoc()) {
        $name = htmlspecialchars($row['name']);
        $department = htmlspecialchars($row['department']);
        $filename = basename($row['filename']);
        $filepath = htmlspecialchars($row['filename']);
        $uploaded_at = htmlspecialchars($row['uploaded_at']);

        echo "<tr>
                <td>$name</td>
                <td>$department</td>
                <td>$filename</td>
                <td><a href='$filepath' download>Download</a></td>
                <td>$uploaded_at</td>
              </tr>";
    }
    ?>
</table>
</body>
</html>