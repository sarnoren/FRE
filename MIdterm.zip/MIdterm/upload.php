<?php include 'db_connect.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Upload Resume</title>
    <link rel="stylesheet" href="upload.css">
</head>
<body>

<div class="container">
    <h2>Upload Resume</h2>
    <form action="upload.php" method="post" enctype="multipart/form-data">
        <label for="name">Name</label>
        <input type="text" name="name" id="name" required>

        <label for="department">Department</label>
        <input type="text" name="department" id="department">

        <label for="resume">Resume (PDF or DOCX)</label>
        <input type="file" name="resume" id="resume" accept=".pdf,.docx" required>

        <input type="submit" name="submit" value="Upload">
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $name = $conn->real_escape_string($_POST['name']);
        $department = $conn->real_escape_string($_POST['department']);

        $file = $_FILES['resume'];
        $filename = basename($file['name']);
        $targetDir = "resume/";
        $targetFile = $targetDir . time() . "_" . $filename;

        $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
        $allowedTypes = ['pdf', 'docx'];

        if (in_array($fileType, $allowedTypes)) {
            if (move_uploaded_file($file['tmp_name'], $targetFile)) {
                $stmt = $conn->prepare("INSERT INTO resumes (name, department, filename) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $name, $department, $targetFile);
                $stmt->execute();

                echo '<div class="message success">Resume uploaded successfully!</div>';
            } else {
                echo '<div class="message error">Error uploading file.</div>';
            }
        } else {
            echo '<div class="message error">Only PDF and DOCX files are allowed.</div>';
        }
    }
    ?>
</div>
<div style="text-align: right; margin-bottom: 10px;">
    <a href="logout.php" style="padding: 8px 16px; background: #dc3545; color: #fff; text-decoration: none; border-radius: 5px;">Logout</a>
</div>

</body>
</html>